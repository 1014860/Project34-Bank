import java.io.*;
import java.util.Scanner;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.border.Border;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;/*
import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;*/
public class Main{
	public static void main(String[] args)
	{
		ImageIcon GUI = new ImageIcon("GUI.png");
		ImageIcon GUI_HOOFDPAGINA_2_EN = new ImageIcon("GUI_HOOFDPAGINA_2_EN.png");
		ImageIcon GUI_HOOFDPAGINA_2_NL = new ImageIcon("GUI_HOOFDPAGINA_2_NL.png");		
		ImageIcon GUI_HOOFDPAGINA_3_NL = new ImageIcon("GUI_HOOFDPAGINA_3_NL.png");		
		ImageIcon GUI_HOOFDPAGINA_3_EN = new ImageIcon("GUI_HOOFDPAGINA_3_EN.png");			
		ImageIcon SALDO_CHECKEN_EN = new ImageIcon("SALDO_CHECKEN_EN.png");
		ImageIcon SALDO_CHECKEN_NL = new ImageIcon("SALDO_CHECKEN_NL.png");
		ImageIcon PIN_PAGINA_AUTO_EN = new ImageIcon("PIN_PAGINA_AUTO_EN.png");
		ImageIcon PIN_PAGINA_AUTO_NL = new ImageIcon("PIN_PAGINA_AUTO_NL.png");				
		ImageIcon PIN_PAGINA_HANDMATIG_EN = new ImageIcon("PIN_PAGINA_HANDMATIG_EN.png");
		ImageIcon PIN_PAGINA_HANDMATIG_NL = new ImageIcon("PIN_PAGINA_HANDMATIG_NL.png");
		ImageIcon PIN_PAGINA_SOORT_BILJET_EN = new ImageIcon("PIN_PAGINA_SOORT_BILJET_EN.png");
		ImageIcon PIN_PAGINA_SOORT_BILJET_NL = new ImageIcon("PIN_PAGINA_SOORT_BILJET_NL.png");
		ImageIcon PIN_PAGINA_TRANSACTIEBON_EN = new ImageIcon("PIN_PAGINA_TRANSACTIEBON_EN.png");
		ImageIcon PIN_PAGINA_TRANSACTIEBON_NL = new ImageIcon("PIN_PAGINA_TRANSACTIEBON_NL.png");
		ImageIcon END = new ImageIcon("END.png");
		Border border = BorderFactory.createLineBorder(Color.blue,4);//color, size(width)
		
		MySQL mysql = new MySQL();
		
		Send_serial send_serial = new Send_serial();
		send_serial.send_char('a');
		send_serial.start();
	
		
		//FIELDS
		int times_incorrect = 0;
		String card_UID = "";
		send_serial.send = 0;
		int language_change = 0;
		String pin_code = "";
		int pincode = 0;
		int pinamount = 0;
		int snelkeuzebedrag = 0; 
		String pin_amount = "";
		int voorkeur_biljetten = 0; //30 for 30, 50 for 50;
		int transactiebon = 0; //1 = yes, 0 = no.
		
		JLabel label = new JLabel(); //create a label//
		label.setIcon(GUI);
		//label.setIcon(image2);//for setting another page
		label.setText("");
		label.setHorizontalTextPosition(JLabel.CENTER); //left, center of right//
		label.setVerticalTextPosition(JLabel.CENTER); //top, center or bottom//
		label.setForeground(new Color(0x123456));
		//label.setFont();
		label.setIconTextGap(100);//int value//100 is example!!//
		label.setBackground(Color.black);
		label.setOpaque(true);//display background color//
		label.setBorder(border);
		label.setVerticalAlignment(JLabel.TOP);//top,center,bottom//
		label.setHorizontalAlignment(JLabel.CENTER);//left,center,right//
		label.setBounds(0,0,250,250);//x//,y,width,height//
		
		JFrame frame = new JFrame();
		frame.setTitle("BANK GUI");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		frame.setSize(1920,1080);//WIDTH, HEIGHT//
		frame.setVisible(true);
		//frame.setLayout(null);//this or pack//
		//frame.pack();//this or setLayout//
		frame.add(label);
		//Button_press button_press = new Button_press(frame, label, GUI);
		int counter = 1;
		int language = 0; //0 for dutch, 1 for english//
		//button_press.set_image(GUI);
		label.setIcon(GUI);
		Scanner scan = new Scanner(System.in);
		//while(language == 0 && button_press.get_counter() <8)
		boolean inmenu = true;
		String currentpage = "GUI";
		while(inmenu == true)
		{
		
		language = 0;
		String amount_input = "";
		String PIN_INPUT = "";
		int x = 0;
		while(language ==0)
		{
			String userinput_string = send_serial.input_string;
			
			char userinput_char = 'z'; //DONT USE 'Z' IN PAGE NAVIGATION
			
			if(userinput_string != null)
			{
				userinput_char = userinput_string.charAt(0);//THIS FUCKING WORKS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!()()()(_(()()()_()
			}
			
			String a;
			a = ""+userinput_char;
			
			//PAGE NAVIGATION
			
			
			if(a.equals("M") && currentpage == "GUI")//REPLACE "N" BY INPUT FROM ARDUINO LATER. (WHEN PESS IS INSERTED, GO TO NEXT PAGE I MEAN)
			{
				send_serial.send = 1;
				send_serial.send_data = 'T';
				int y = 0;
				System.out.println(send_serial.message_sent);
				while(send_serial.message_sent == 0)
				{
					System.out.println(send_serial.message_sent);
				}
				card_UID = send_serial.card_uid;
				currentpage = "GUI_HOOFDPAGINA_2_NL";
				label.setIcon(GUI_HOOFDPAGINA_2_NL);
				label.setText("Voer uw pincode in");//SET **** BASED ON INPUT FROM SERIAL
				

			}
			
			card_UID = send_serial.card_uid;
			
			//PAGE FUNCTIONALITY
			if(currentpage.equals("SALDO_CHECKEN_NL"))
			{
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if(a.equals("A")&&send_serial.new_a == 1&&send_serial.new_a == 1)
				{
					currentpage = "SALDO_CHECKEN_EN";
					language = 1;
					label.setText("");
					label.setIcon(SALDO_CHECKEN_EN);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				String checkfromdatabase = mysql.getBalance(card_UID);
				label.setText(checkfromdatabase);//AND RETRIEVE BALANCE FROM DATABASE
			}
			else if(currentpage.equals("PIN_PAGINA_SOORT_BILJET_NL"))
			{
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if( a.equals("A")&&send_serial.new_a == 1)
				{
					 
					currentpage = "PIN_PAGINA_SOORT_BILJET_EN";
					language = 1;
					label.setText("");
					label.setIcon(PIN_PAGINA_SOORT_BILJET_EN);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				else if(a.equals("1"))
				{
					//10 eurobiljetten
					voorkeur_biljetten = 10;
					send_serial.send = 1;
					send_serial.send_data = 'X';
					currentpage = "PIN_PAGINA_TRANSACTIEBON_NL";
					label.setIcon(PIN_PAGINA_TRANSACTIEBON_NL);
					label.setText("");
				}
				else if(a.equals("2"))
				{
					//20 eurobiljetten
					voorkeur_biljetten = 20;
					send_serial.send = 1;
					send_serial.send_data = 'B';
					currentpage = "PIN_PAGINA_TRANSACTIEBON_NL";
					label.setIcon(PIN_PAGINA_TRANSACTIEBON_NL);
					label.setText("");
				}
			}
			else if(currentpage.equals("PIN_PAGINA_TRANSACTIEBON_NL"))
			{
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if( a.equals("A")&&send_serial.new_a == 1)
				{
					 
					currentpage = "PIN_PAGINA_TRANSACTIEBON_EN";
					language = 1;
					label.setText("");
					label.setIcon(PIN_PAGINA_TRANSACTIEBON_EN);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				else if(a.equals("Y"))
				{
					//TRANSACTIEBON
					String transactie_id = mysql.getTransactionID(card_UID, pinamount);
					transactiebon = 1;
					send_serial.send = 1;
					send_serial.send_data = 'L';
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if(a.equals("N"))
				{
					//GEEN TRANSACTIEBON
					String transactie_id = mysql.getTransactionID(card_UID, pinamount);
					transactiebon = 0;
					send_serial.send = 1;
					send_serial.send_data = 'K';
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
			}
			else if(currentpage.equals("PIN_PAGINA_AUTO_NL"))//FULLY FUCNTIONAL
			{
				String check = "";
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if(a.equals("A")&&send_serial.new_a == 1)
				{
					 
					currentpage = "PIN_PAGINA_AUTO_EN";
					language = 1;
					label.setText("");
					label.setIcon(PIN_PAGINA_AUTO_EN);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				else if(a.equals("*"))
				{
					currentpage = "PIN_PAGINA_HANDMATIG_NL";
					label.setIcon(PIN_PAGINA_HANDMATIG_NL);
					label.setText("Voer hier uw bedrag in");//NEED INPUT FROM SERIAL TO DISPLAY AMOUNT
				}
				if(a.equals("1"))
				{
					//30 euro pinnen
					snelkeuzebedrag = 30;
					send_serial.send = 1;
					send_serial.send_data = 'O';
					check = mysql.withdraw(card_UID, pin_code, 30);
				}
				else if(a.equals("2"))
				{
					//50 euro pinnen
					snelkeuzebedrag = 50;
					send_serial.send = 1;
					send_serial.send_data = 'M';
					check = mysql.withdraw(card_UID, pin_code, 50);
				}
				else if(a.equals("3"))
				{
					//100 euro pinnen
					snelkeuzebedrag = 100;
					send_serial.send = 1;
					send_serial.send_data = 'S';
					check = mysql.withdraw(card_UID, pin_code, 100);
				}
				if(check.equals("true"))
				{
					//pinamount = Integer.parseInt(pin_amount);
					currentpage = "PIN_PAGINA_SOORT_BILJET_NL";
					label.setIcon(PIN_PAGINA_SOORT_BILJET_NL);
					label.setText("");
				}
				else if(check.equals("false_entered_amount"))
				{
					currentpage = "PIN_PAGINA_AUTO_NL";
					label.setIcon(PIN_PAGINA_AUTO_NL);
					label.setText("");
				}
				else if(check.equals("false_balance"))
				{
					currentpage = "PIN_PAGINA_AUTO_NL";
					label.setIcon(PIN_PAGINA_AUTO_NL);
					label.setText("Er staat niet genoeg geld op uw rekening");//CHANGE FOR ENGLISH
				}
				
			}
			
			else if(currentpage.equals("PIN_PAGINA_HANDMATIG_NL") == true)//FULLY FUCNTIONAL
			{
				send_serial.check_input_count = 1;
				label.setText(pin_amount);
				
				if(send_serial.button_pressed > 0)//DETECTING BUTTON PRESS FOR DISPLAY OF ENTERED AMOUNT IN KEYPAD++
				{
					if(a.equals("D"))
					{
						currentpage = "END";
						label.setIcon(END);
						label.setText("");
						label.setText("");
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
					else if( a.equals("A")&&send_serial.new_a == 1)
					{
						 
						currentpage = "PIN_PAGINA_HANDMATIG_EN";
						language = 1;
						label.setText("");
						label.setIcon(PIN_PAGINA_HANDMATIG_EN);
						label.setText("");
						label.setText("");
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
					
					if(a.equals("0")||a.equals("1")||a.equals("2")||a.equals("3")||a.equals("4")||a.equals("5")||a.equals("6")||a.equals("7")||a.equals("8")||a.equals("9"))
					{
						pin_amount = send_serial.amount_string; 
						pinamount = Integer.parseInt(pin_amount);
					}
					if(a.equals("Y"))
					{
						if(pinamount>10000 || pinamount<0)
						{
							currentpage = "PIN_PAGINA_HANDMATIG_NL";
							label.setIcon(PIN_PAGINA_HANDMATIG_NL);
							label.setText("Vul aub een bedrag tussen 0 en 10000 in");
						}
						else
						{
							String check = mysql.withdraw(card_UID, pin_code, pinamount);
							if(check.equals("true"))
							{
								currentpage = "PIN_PAGINA_SOORT_BILJET_NL";
								label.setIcon(PIN_PAGINA_SOORT_BILJET_NL);
								label.setText("");
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
							}
							else if(check.equals("false_entered_amount"))
							{
								currentpage = "PIN_PAGINA_HANDMATIG_NL";
								label.setIcon(PIN_PAGINA_HANDMATIG_NL);
								label.setText("");
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
							}
							else if(check.equals("false_balance"))
							{
								currentpage = "PIN_PAGINA_HANDMATIG_NL";
								label.setIcon(PIN_PAGINA_HANDMATIG_NL);
								label.setText("Er staat niet genoeg geld op uw rekening");//CHANGE FOR ENGLISH
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
							}
						}
						
					}
					if(a.equals("N"))
					{
						label.setText("");
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
				}
			}

			else if(currentpage.equals("GUI_HOOFDPAGINA_3_NL") == true)//FULLY FUCNTIONAL
			{
				if(a.equals("C"))
				{
				currentpage = "SALDO_CHECKEN_NL";
				label.setIcon(SALDO_CHECKEN_NL);
				label.setText("Uw huidige saldo: ");//GET SALDO FROM SERIAL/DATABASE
				}
				
				else if(a.equals("#"))
				{
				currentpage = "PIN_PAGINA_AUTO_NL";
				label.setIcon(PIN_PAGINA_AUTO_NL);
				label.setText("");
				}
				
				else if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if( a.equals("A")&&send_serial.new_a == 1)
				{
					currentpage = "GUI_HOOFDPAGINA_3_EN";
					language = 1;
					label.setText("");
					label.setIcon(GUI_HOOFDPAGINA_3_EN);
					
				}
			}
			else if(currentpage.equals("END"))
			{
				send_serial.send = 1;
				send_serial.send_data = 'D';
				if(send_serial.message_sent == 0)
				{
				}
				else
				{
					currentpage = "GUI";
					label.setText("");
					label.setIcon(GUI);
				}
				
					
				
			}
			else if(currentpage.equals("GUI_HOOFDPAGINA_2_NL") == true)
			{
				card_UID = send_serial.card_uid;
				if(a.equals("D"))
					{
						currentpage = "END";
						label.setIcon(END);
						label.setText("");
						label.setText("");
						PIN_INPUT = "";
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
					else if( a.equals("A")&&send_serial.new_a == 1)
					{
						currentpage = "GUI_HOOFDPAGINA_2_EN";
						language = 1;
						label.setText("");
						label.setIcon(GUI_HOOFDPAGINA_2_EN);
						label.setText("");
						label.setText("");
						PIN_INPUT = "";
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
				send_serial.check_input_count = 1;
				if(send_serial.button_pressed > 0)//DETECTING BUTTON PRESS FOR DISPLAY OF ENTERED AMOUNT IN KEYPAD++
				{
					if(a.equals("0")||a.equals("1")||a.equals("2")||a.equals("3")||a.equals("4")||a.equals("5")||a.equals("6")||a.equals("7")||a.equals("8")||a.equals("9"))
					{
						if(send_serial.button_pressed == 1)
						{
							label.setText("*");
						}
						else if(send_serial.button_pressed == 2)
						{
							label.setText("**");
						}
						else if(send_serial.button_pressed == 3)
						{
							label.setText("***");
						}
						else if(send_serial.button_pressed == 4)
						{
							label.setText("****");
							
						}
					}
					if(a.equals("Y"))
					{
						if(send_serial.button_pressed==4)
						{
							System.out.println(card_UID);
							//card_UID = "D3 3A 85 16";
							//RETRIEVE PIN_CODE
							pin_code = send_serial.amount_string;
							//CHECK IF CORRECT IN ARDUINO/DATABASE
							String check_pin = mysql.pinCheck(card_UID, pin_code);
							if(check_pin.equals("true"))
							{
								pincode = Integer.parseInt(pin_code);
								label.setText(amount_input);
								currentpage = "GUI_HOOFDPAGINA_3_NL";
								label.setIcon(GUI_HOOFDPAGINA_3_NL);
								label.setText("");
								PIN_INPUT = "";
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
								
							}
							else if(check_pin.equals("false"))
							{
								times_incorrect++;
								amount_input = "";
								PIN_INPUT = "";
								label.setText(PIN_INPUT);
								send_serial.amount_string = "";
								
								if(times_incorrect == 3)
								{
									currentpage = "END";
									label.setIcon(END);
									label.setText("");
									label.setText("");
									PIN_INPUT = "";
									amount_input = "";
									send_serial.check_input_count = 0;
									send_serial.amount_string = "";
								}
							}
							
							
							
							//send_serial.send = 0;
							
							
						}
						else
						{
							amount_input = "";
							PIN_INPUT = "";
							label.setText(PIN_INPUT);
							send_serial.amount_string = "";
						}
					}
					if(a.equals("N"))
					{
						label.setText("");
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
				}
			}
		} ////////////////////////////////////
		
		while(language == 1)
		{
			String userinput_string = send_serial.input_string;
			
			char userinput_char = 'z'; //DONT USE 'Z' IN PAGE NAVIGATION
			
			if(userinput_string != null)
			{
				userinput_char = userinput_string.charAt(0);//THIS FUCKING WORKS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!()()()(_(()()()_()
			}
			
			String a;
			a = ""+userinput_char;
			
			//PAGE NAVIGATION
			
			
			if(a.equals("M") && currentpage == "GUI")//REPLACE "N" BY INPUT FROM ARDUINO LATER. (WHEN PESS IS INSERTED, GO TO NEXT PAGE I MEAN)
			{
				send_serial.send = 1;
				send_serial.send_data = 'T';
				int y = 0;
				System.out.println(send_serial.message_sent);
				while(send_serial.message_sent == 0)
				{
					System.out.println(send_serial.message_sent);
				}
				card_UID = send_serial.card_uid;
				currentpage = "GUI_HOOFDPAGINA_2_NL";
				label.setIcon(GUI_HOOFDPAGINA_2_NL);
				label.setText("Voer uw pincode in");//SET **** BASED ON INPUT FROM SERIAL
				

			}
			
			card_UID = send_serial.card_uid;
			
			//PAGE FUNCTIONALITY
			if(currentpage.equals("SALDO_CHECKEN_NL"))
			{
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if(a.equals("A")&&send_serial.new_a == 1&&send_serial.new_a == 1)
				{
					currentpage = "SALDO_CHECKEN_NL";
					language = 0;
					label.setText("");
					label.setIcon(SALDO_CHECKEN_NL);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				String checkfromdatabase = mysql.getBalance(card_UID);
				label.setText(checkfromdatabase);//AND RETRIEVE BALANCE FROM DATABASE
			}
			else if(currentpage.equals("PIN_PAGINA_SOORT_BILJET_NL"))
			{
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if( a.equals("A")&&send_serial.new_a == 1)
				{
					 
					currentpage = "PIN_PAGINA_SOORT_BILJET_NL";
					language = 0;
					label.setText("");
					label.setIcon(PIN_PAGINA_SOORT_BILJET_NL);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				else if(a.equals("1"))
				{
					//10 eurobiljetten
					voorkeur_biljetten = 10;
					send_serial.send = 1;
					send_serial.send_data = 'X';
					currentpage = "PIN_PAGINA_TRANSACTIEBON_NL";
					label.setIcon(PIN_PAGINA_TRANSACTIEBON_NL);
					label.setText("");
				}
				else if(a.equals("2"))
				{
					//20 eurobiljetten
					voorkeur_biljetten = 20;
					send_serial.send = 1;
					send_serial.send_data = 'B';
					currentpage = "PIN_PAGINA_TRANSACTIEBON_NL";
					label.setIcon(PIN_PAGINA_TRANSACTIEBON_NL);
					label.setText("");
				}
			}
			else if(currentpage.equals("PIN_PAGINA_TRANSACTIEBON_NL"))
			{
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if( a.equals("A")&&send_serial.new_a == 1)
				{
					 
					currentpage = "PIN_PAGINA_TRANSACTIEBON_NL";
					language = 0;
					label.setText("");
					label.setIcon(PIN_PAGINA_TRANSACTIEBON_NL);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				else if(a.equals("Y"))
				{
					//TRANSACTIEBON
					String transactie_id = mysql.getTransactionID(card_UID, pinamount);
					transactiebon = 1;
					send_serial.send = 1;
					send_serial.send_data = 'L';
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if(a.equals("N"))
				{
					//GEEN TRANSACTIEBON
					String transactie_id = mysql.getTransactionID(card_UID, pinamount);
					transactiebon = 0;
					send_serial.send = 1;
					send_serial.send_data = 'K';
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
			}
			else if(currentpage.equals("PIN_PAGINA_AUTO_NL"))//FULLY FUCNTIONAL
			{
				String check = "";
				if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if(a.equals("A")&&send_serial.new_a == 1)
				{
					 
					currentpage = "PIN_PAGINA_AUTO_NL";
					language = 0;
					label.setText("");
					label.setIcon(PIN_PAGINA_AUTO_NL);
				}
				else if(a.equals("B"))
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					label.setText("");
				}
				else if(a.equals("*"))
				{
					currentpage = "PIN_PAGINA_HANDMATIG_NL";
					label.setIcon(PIN_PAGINA_HANDMATIG_NL);
					label.setText("Voer hier uw bedrag in");//NEED INPUT FROM SERIAL TO DISPLAY AMOUNT
				}
				if(a.equals("1"))
				{
					//30 euro pinnen
					snelkeuzebedrag = 30;
					send_serial.send = 1;
					send_serial.send_data = 'O';
					check = mysql.withdraw(card_UID, pin_code, 30);
				}
				else if(a.equals("2"))
				{
					//50 euro pinnen
					snelkeuzebedrag = 50;
					send_serial.send = 1;
					send_serial.send_data = 'M';
					check = mysql.withdraw(card_UID, pin_code, 50);
				}
				else if(a.equals("3"))
				{
					//100 euro pinnen
					snelkeuzebedrag = 100;
					send_serial.send = 1;
					send_serial.send_data = 'S';
					check = mysql.withdraw(card_UID, pin_code, 100);
				}
				if(check.equals("true"))
				{
					//pinamount = Integer.parseInt(pin_amount);
					currentpage = "PIN_PAGINA_SOORT_BILJET_NL";
					label.setIcon(PIN_PAGINA_SOORT_BILJET_NL);
					label.setText("");
				}
				else if(check.equals("false_NLtered_amount"))
				{
					currentpage = "PIN_PAGINA_AUTO_NL";
					label.setIcon(PIN_PAGINA_AUTO_NL);
					label.setText("");
				}
				else if(check.equals("false_balance"))
				{
					currentpage = "PIN_PAGINA_AUTO_NL";
					label.setIcon(PIN_PAGINA_AUTO_NL);
					label.setText("Er staat niet genoeg geld op uw rekening");//CHANGE FOR ENGLISH
				}
				
			}
			
			else if(currentpage.equals("PIN_PAGINA_HANDMATIG_NL") == true)//FULLY FUCNTIONAL
			{
				send_serial.check_input_count = 1;
				label.setText(pin_amount);
				
				if(send_serial.button_pressed > 0)//DETECTING BUTTON PRESS FOR DISPLAY OF ENTERED AMOUNT IN KEYPAD++
				{
					if(a.equals("D"))
					{
						currentpage = "END";
						label.setIcon(END);
						label.setText("");
						label.setText("");
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
					else if( a.equals("A")&&send_serial.new_a == 1)
					{
						 
						currentpage = "PIN_PAGINA_HANDMATIG_NL";
						language = 0;
						label.setText("");
						label.setIcon(PIN_PAGINA_HANDMATIG_NL);
						label.setText("");
						label.setText("");
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
					
					if(a.equals("0")||a.equals("1")||a.equals("2")||a.equals("3")||a.equals("4")||a.equals("5")||a.equals("6")||a.equals("7")||a.equals("8")||a.equals("9"))
					{
						pin_amount = send_serial.amount_string; 
						pinamount = Integer.parseInt(pin_amount);
					}
					if(a.equals("Y"))
					{
						if(pinamount>10000 || pinamount<0)
						{
							currentpage = "PIN_PAGINA_HANDMATIG_NL";
							label.setIcon(PIN_PAGINA_HANDMATIG_NL);
							label.setText("Vul aub een bedrag tussen 0 en 10000 in");
						}
						else
						{
							String check = mysql.withdraw(card_UID, pin_code, pinamount);
							if(check.equals("true"))
							{
								currentpage = "PIN_PAGINA_SOORT_BILJET_NL";
								label.setIcon(PIN_PAGINA_SOORT_BILJET_NL);
								label.setText("");
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
							}
							else if(check.equals("false_NLtered_amount"))
							{
								currentpage = "PIN_PAGINA_HANDMATIG_NL";
								label.setIcon(PIN_PAGINA_HANDMATIG_NL);
								label.setText("");
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
							}
							else if(check.equals("false_balance"))
							{
								currentpage = "PIN_PAGINA_HANDMATIG_NL";
								label.setIcon(PIN_PAGINA_HANDMATIG_NL);
								label.setText("Er staat niet genoeg geld op uw rekening");//CHANGE FOR ENGLISH
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
							}
						}
						
					}
					if(a.equals("N"))
					{
						label.setText("");
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
				}
			}

			else if(currentpage.equals("GUI_HOOFDPAGINA_3_NL") == true)//FULLY FUCNTIONAL
			{
				if(a.equals("C"))
				{
				currentpage = "SALDO_CHECKEN_NL";
				label.setIcon(SALDO_CHECKEN_NL);
				label.setText("Uw huidige saldo: ");//GET SALDO FROM SERIAL/DATABASE
				}
				
				else if(a.equals("#"))
				{
				currentpage = "PIN_PAGINA_AUTO_NL";
				label.setIcon(PIN_PAGINA_AUTO_NL);
				label.setText("");
				}
				
				else if(a.equals("D"))
				{
					currentpage = "END";
					label.setIcon(END);
					label.setText("");
				}
				else if( a.equals("A")&&send_serial.new_a == 1)
				{
					currentpage = "GUI_HOOFDPAGINA_3_NL";
					language = 0;
					label.setText("");
					label.setIcon(GUI_HOOFDPAGINA_3_NL);
					
				}
			}
			else if(currentpage.equals("END"))
			{
				send_serial.send = 1;
				send_serial.send_data = 'D';
				if(send_serial.message_sent == 0)
				{
				}
				else
				{
					currentpage = "GUI";
					label.setText("");
					label.setIcon(GUI);
				}
				
					
				
			}
			else if(currentpage.equals("GUI_HOOFDPAGINA_2_NL") == true)
			{
				card_UID = send_serial.card_uid;
				if(a.equals("D"))
					{
						currentpage = "END";
						label.setIcon(END);
						label.setText("");
						label.setText("");
						PIN_INPUT = "";
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
					else if( a.equals("A")&&send_serial.new_a == 1)
					{
						currentpage = "GUI_HOOFDPAGINA_2_NL";
						language = 0;
						label.setText("");
						label.setIcon(GUI_HOOFDPAGINA_2_NL);
						label.setText("");
						label.setText("");
						PIN_INPUT = "";
						amount_input = "";
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
				send_serial.check_input_count = 1;
				if(send_serial.button_pressed > 0)//DETECTING BUTTON PRESS FOR DISPLAY OF ENTERED AMOUNT IN KEYPAD++
				{
					if(a.equals("0")||a.equals("1")||a.equals("2")||a.equals("3")||a.equals("4")||a.equals("5")||a.equals("6")||a.equals("7")||a.equals("8")||a.equals("9"))
					{
						if(send_serial.button_pressed == 1)
						{
							label.setText("*");
						}
						else if(send_serial.button_pressed == 2)
						{
							label.setText("**");
						}
						else if(send_serial.button_pressed == 3)
						{
							label.setText("***");
						}
						else if(send_serial.button_pressed == 4)
						{
							label.setText("****");
							
						}
					}
					if(a.equals("Y"))
					{
						if(send_serial.button_pressed==4)
						{
							System.out.println(card_UID);
							//card_UID = "D3 3A 85 16";
							//RETRIEVE PIN_CODE
							pin_code = send_serial.amount_string;
							//CHECK IF CORRECT IN ARDUINO/DATABASE
							String check_pin = mysql.pinCheck(card_UID, pin_code);
							if(check_pin.equals("true"))
							{
								pincode = Integer.parseInt(pin_code);
								label.setText(amount_input);
								currentpage = "GUI_HOOFDPAGINA_3_NL";
								label.setIcon(GUI_HOOFDPAGINA_3_NL);
								label.setText("");
								PIN_INPUT = "";
								amount_input = "";
								send_serial.check_input_count = 0;
								send_serial.amount_string = "";
								
							}
							else if(check_pin.equals("false"))
							{
								times_incorrect++;
								amount_input = "";
								PIN_INPUT = "";
								label.setText(PIN_INPUT);
								send_serial.amount_string = "";
								
								if(times_incorrect == 3)
								{
									currentpage = "END";
									label.setIcon(END);
									label.setText("");
									label.setText("");
									PIN_INPUT = "";
									amount_input = "";
									send_serial.check_input_count = 0;
									send_serial.amount_string = "";
								}
							}
							
							
							
							//send_serial.send = 0;
							
							
						}
						else
						{
							amount_input = "";
							PIN_INPUT = "";
							label.setText(PIN_INPUT);
							send_serial.amount_string = "";
						}
					}
					if(a.equals("N"))
					{
						label.setText("");
						send_serial.check_input_count = 0;
						send_serial.amount_string = "";
					}
				}
			}
		}//////// 
		}
		counter = 1;
		//button_press.set_image(GUI);
		label.setIcon(GUI);
		}
	





	}


