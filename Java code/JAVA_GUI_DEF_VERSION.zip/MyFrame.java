import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.border.Border;



public class MyFrame extends GUI_PROJECT{
	ImageIcon image = new ImageIcon("END.jpg");
	MyFrame()
	{
		JFrame frame  = new JFrame();
		frame.setIconImage(image.getImage());
		frame.getContentPane().setBackground(new Color(0x123456));
			
	}
	
	public void display()
	{
		
	}
	
	public void change_picture()
	{
		//label.setIcon(GUI);
		//frame.add(label);
		
		
		
		

		
	}




}