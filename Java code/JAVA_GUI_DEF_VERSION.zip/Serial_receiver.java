import java.util.Scanner;
import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;
import java.io.*;
import java.util.*;
import javax.comm.*;

public class Serial_receiver 
{
	public String input = "";
	public SerialPort activePort;
	public SerialPort[] ports = SerialPort.getCommPorts();
	public int button_pressed = 0;
	
	
	
	public String get_input()
	{
		button_pressed--;
		return input;
	}
	
	
	public int get_button_pressed()
	{
		return button_pressed;
	}
	
	public void showAllPort() 
	{
		int i = 0;
		for(SerialPort port : ports) 
		{
			//System.out.print(i + ". " + port.getDescriptivePortName() + " ");
			//System.out.println(port.getPortDescription());
			System.out.println(port.getDescriptivePortName());
			i++;
		}	
	}
	
	public void setPort(int portIndex) 
	{
		activePort = ports[portIndex];
		
		if (activePort.openPort())
		{
			System.out.println(activePort.getPortDescription() + " port opened.");
		}
		
		activePort.addDataListener(new SerialPortDataListener() 
		{
			
			@Override
			public void serialEvent(SerialPortEvent event) 
			{
				int size = event.getSerialPort().bytesAvailable();
				byte[] buffer = new byte[size];
				event.getSerialPort().readBytes(buffer, size);
				//button_pressed=0;
				input = "";
				for(byte b:buffer)
				{
					//System.out.println((char)b);
					input = input+((char)b);
					//System.out.println(input);
				}
				//System.out.println(input);
				button_pressed = 2;
				
			}

			@Override
			public int getListeningEvents() 
			{ 
				return SerialPort.LISTENING_EVENT_DATA_AVAILABLE;  
			}
		});
	}
	
	public void start() 
	{
		showAllPort();
		Scanner reader = new Scanner(System.in);
		System.out.print("Port? ");
		int p = reader.nextInt();
		setPort(p);
		reader.close();
	}
	
	public static void main(String[] args) 
	{
		Serial_receiver mainClass = new Serial_receiver();
		mainClass.start();
	}
	
}
