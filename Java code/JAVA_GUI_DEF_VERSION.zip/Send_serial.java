import arduino.*;
class Send_serial extends Thread{
		public boolean c;
		public int button_pressed = 0;
		public String input_string;
		public int check_input_count = 0;
		public String amount_string = "";
		public int send = 0;
		public int new_a = 0;
		public char send_data = 'z';
		public String write_answer = "";
		public String card_uid = "";
		public int message_sent = 0;
		public synchronized void run()
		{
			Arduino obj = new Arduino("COM3", 9600);
			//obj.openConnection();
			//char abcde = 'a';
			boolean a = true;
			int x = 0;
			while(a)
			{
				if(send == 0)
				{
					obj.openConnection();
					String answer = obj.serialRead(7);
					if(answer.equals("")!=true)
					{
						System.out.println("String answer = "  + answer);
						//a = false;
						//obj.closeConnection();
						if(check_input_count == 1 && answer.charAt(0) != 'A'&& answer.charAt(0) != 'B'&&answer.charAt(0) != 'C'&&answer.charAt(0)!= 'D'&&answer.charAt(0)!= '*'&&answer.charAt(0)!= '#'&&answer.charAt(0) != 'Y'&&answer.charAt(0) != 'N'&&answer.charAt(0) != 'M')
						{
							button_pressed++;
							amount_string = amount_string + answer.charAt(0);
						}
						System.out.println();
						input_string = answer; 
						new_a = 1;
					}
					else if(check_input_count == 0)
					{
						button_pressed = 0;
					}
					new_a = 0;
				}
				else if(send == 1)
				{
					card_uid = "";
					c = true;
					while(c)
					{
						message_sent = 0;
						//obj.openConnection();
						obj.serialWrite(send_data);
						String write_answer = obj.serialRead(20);
						System.out.println("String_____answer = "  + write_answer);
						if(write_answer.equals("")!=true)
						{
							String card_uid_temp =  write_answer.replaceAll("M\n", "").replaceAll("M\r", "").replaceAll("\r", " ").replaceAll("\n", " ");
							int lengte = card_uid_temp.length();
							if(lengte>3)
							for(int i=0;i<11;i++)
							{
								card_uid = card_uid+card_uid_temp.charAt(i);
							}
							System.out.println("Stringanswer: "+write_answer);
							System.out.println("CARD_UID=="+card_uid);
							message_sent = 1;
							c = false;
							//obj.closeConnection();
							//return;
							//write_answer ="";
							this.send = 0;
						}
					}
				
				}
			}	
		}
        public void send_char(char send_this) 
		{
			Arduino obj = new Arduino("COM3", 9600);
			obj.openConnection();
			char abcde = 'a';
			boolean a = true;
			while(a)
			{
				obj.openConnection();
				obj.serialWrite(send_this);
				String answer = obj.serialRead(7);
				System.out.println("String answer = "  + answer);
				if(answer.equals("")!=true)
				{
					System.out.println(answer);
					a = false;
					obj.closeConnection();
					return;
				}
			}
		}
		//public String get_char()
		//{
			/*Arduino obj = new Arduino("COM3", 9600);
			obj.openConnection();
			//char abcde = 'a';
			boolean a = true;
			while(a)
			{
				//obj.openConnection();
				String answer = obj.serialRead(7);
				//System.out.println("String answer = "  + answer);
				if(answer.equals("")!=true)
				{
					a = false;
					obj.closeConnection();
					return answer;
				}
			}*/
			//return "";
		//}
	//SLEEP METHODE	
	public void delay(int ms)throws InterruptedException
	{
		sleep(ms);
	}
}