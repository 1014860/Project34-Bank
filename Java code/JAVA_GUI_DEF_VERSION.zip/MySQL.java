import java.sql.*;

public class MySQL {
    private Connection conn;
    private Statement stmt;

    public MySQL() {
        try {
            String url = "jdbc:mysql://localhost:3306/project_bank?user=root&password=root";
			
            conn = DriverManager.getConnection(url);
            if (conn != null) {
				stmt = conn.createStatement();
                System.out.println("Connected to the BANK");
            }
        } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
        }
    }
public String getIban(String card){		//Kijkt hoegroot de balance is van de kaart dat is gescand
		String iban = "";
		try {
			ResultSet rs = stmt.executeQuery("SELECT iban FROM accounts JOIN cards ON accounts.card_id = cards.card_id WHERE card_number = \"" + card + "\"");
			if(rs.next()){
                iban = rs.getString(1);
				System.out.println(iban);
			}
		} catch(Exception ex){
			System.out.println(ex);
		}
		return iban;
	}
    public String pinCheck(String card, String pin){
        if(correctCard(card)){
            if(notBlocked(card)){
                if(correctPincode(card, pin)){
                    System.out.println("pin correct");
                    resetAttempts(card);
					totalAttempts(card);
                    return "true";
                } else{
                    System.out.println("pin incorrect");
                    incrementAttempts(card);
					totalAttempts(card);
                    if(noAttemptsLeft(card)){
                        System.out.println("no attemps left, card will be blocked");
                        blockCard(card);
                    }
                }
            } else{
                System.out.println("card blocked");
            }
        } else{
            System.out.println("card incorrect");
        }
        return "false";
    }

    public String withdraw(String card, String pin, double amount){
		if(amount > 0){
			if(enoughBalance(card, pin, amount)){
				lowerBalance(getIban(card), amount);
				transaction(getIban(card), amount);
				return "true";
			} else{
				System.out.println("Not enough balance");
				return "false_balance";
			}
		} else{
			System.out.println("Amount is negative or zero");
			return "false_entered_amount";
		}
        //return "false";
	}

	// The balance will be returned
	public String getBalance(String card){		//Kijkt hoegroot de balance is van de kaart dat is gescand
		String balance = "";
		try {
			ResultSet rs = stmt.executeQuery("SELECT balance FROM accounts JOIN cards ON accounts.card_id = cards.card_id WHERE card_number = \"" + card + "\"");
			if(rs.next()){
                balance = rs.getString(1);
				System.out.println(balance);
			}
		} catch(Exception ex){
			System.out.println(ex);
		}
		return balance;
	}

	public String getTransactionID(String card, double amount){
		String transactionID = "ID unknown";
		try {																				//Kan de transactie id terugvinden.
			ResultSet rs = stmt.executeQuery("SELECT transactions.transaction_id FROM accounts JOIN cards ON accounts.card_id = cards.card_id JOIN transactions ON transactions.iban = accounts.iban WHERE card_number = \"" + card + "\" AND transaction_amount = \"" + (double)amount + "\" ORDER BY transaction_id DESC LIMIT 1");
			if(rs.next()){
				transactionID = rs.getString(1);
				int idLength = transactionID.length();
				for(int i = idLength; i < 8; i++){
					transactionID = "0" + transactionID;
				}
			}
		} catch(Exception ex){
			System.out.println(ex);
		}
		return transactionID;
	}

    private boolean check(String query){	//Als de check query's gelijk zijn aan 1 worden deze geaccepteerd.	
		boolean result = false;
		try {
			ResultSet rs = stmt.executeQuery(query);
			if(rs.next()){
                if(rs.getString(1).equals("1")){
					result = true;
				}
			}
		} catch(Exception ex){
			System.out.println(ex);
		}
		return result;
	}

	private boolean enoughBalance(String card, String pin, double amount){
		return check("SELECT balance >= \"" + (double)amount + "\" FROM accounts JOIN cards ON accounts.card_id = cards.card_id WHERE card_number = \"" + card + "\" AND pincode = \"" + pin + "\"");	//Kijkt of het amount dat gevraagd is wel gepind kan worden.
	}

	private boolean correctCard(String card){
        return check("SELECT COUNT(*) FROM cards WHERE card_number = \"" + card + "\"");	//Controleert hoeveel kaarten er zijn voor voor deze card_number.
	}

	private boolean notBlocked(String card){
        return check("SELECT blocked = 0 FROM cards WHERE card_number = \"" + card + "\"");	//Kijkt of de kaart is geblokeerd of niet
	}

	private boolean correctPincode(String card, String pin){
        return check("SELECT pincode = \"" + pin + "\" FROM cards WHERE card_number = \"" + card + "\"");	//Chekt of de pin van de gekozen kaart correct is.
	}

	private boolean noAttemptsLeft(String card){
        return check("SELECT attempts >= 3 FROM cards WHERE card_number = \"" + card + "\"");	//Controleert of er drie foutpogingen zijn gedaan.
	}

    private void update(String query){
		try {
			stmt.executeUpdate(query);
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

    private void resetAttempts(String card){
		update("UPDATE cards SET attempts = 0 WHERE card_number = \"" + card + "\""); //Reset de attempts naar nul wanneer er succesvol is ingelogd.
	}

	private void incrementAttempts(String card){
		update("UPDATE cards SET attempts = attempts + 1 WHERE card_number = \"" + card + "\"");	//Voegt 1 attempt toe aan elke foutpoging.
	}

	private void totalAttempts(String card) {
		update("UPDATE cards SET count = count + 1 WHERE card_number = \"" + card + "\"");	//Voegt 1 bij de count toe voor elke inlogpoging.
	}

	private void blockCard(String card){
		update("UPDATE cards SET blocked = 1 WHERE card_number = \"" + card + "\""); //Bij drie foute pogingen achter elkaar wordt de kaart geblokkeerd.
	}

	private void lowerBalance(String iban, double amount){
		update("UPDATE accounts SET balance = balance - \"" + (double)amount + "\" WHERE iban = \"" + iban + "\"");	//Als er gepind is wordt de balance vermindert.
	}

	private void transaction(String iban, double amount){
		update("INSERT INTO transactions (transaction_amount, iban, transaction_date) VALUES (\"" + (double)amount + "\", \"" + iban + "\", CURRENT_TIMESTAMP())");	//De informatie van de transactie wordt opgeslagen in de database.
	}
}